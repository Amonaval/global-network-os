# Mission Template

Use one document like this for each major mission.

# <MISSION-ID> — <MISSION NAME>

## Intent

What user/business problem are we solving?

## Why now

Why is this more important than adjacent roadmap work?

## Success signal

What observable behavior/result should exist after implementation?

## In scope

- ...
- ...

## Explicitly deferred

Preserve these ideas, but do not implement them in this mission:

- ...

## Current baseline

- Canonical baseline/version: ...
- Relevant existing modules: ...
- Relevant migrations/contracts: ...

## Product principles

- Keep the surface simple.
- Prefer discoverable behavior over hidden power.
- Avoid exposing partially verified behavior as complete.
- Preserve backward compatibility unless explicitly approved otherwise.

## Architecture constraints

- Reuse: ...
- New shared abstraction if needed: ...
- Data/migration rules: ...
- Security/privacy rules: ...
- No unnecessary LLM dependency for deterministic work.

## User journeys / acceptance behavior

### Journey 1

Given ...
When ...
Then ...

### Journey 2

...

## Roles / permissions

| Role | Can view | Can act | Notes |
|---|---|---|---|
| ... | ... | ... | ... |

## Failure and recovery

Define behavior for:

- empty data;
- permission denial;
- network/backend failure;
- invalid input;
- stale/conflicting data;
- partial completion;
- retry/recovery.

## Rollout

Default exposure:

- Hidden / Test / Pilot / Released

Describe differences for demo/playground vs real users if applicable.

## Validation gate

Minimum checks:

- [ ] static/source contract
- [ ] typecheck/lint
- [ ] production build
- [ ] unit/integration tests
- [ ] role/permission matrix
- [ ] browser/E2E journey
- [ ] responsive/mobile
- [ ] migration/database behavior
- [ ] security/privacy behavior
- [ ] regression suite
- [ ] deployed/live verification if required

## Truthful completion status

At delivery classify each part as:

- IMPLEMENTED
- PARTIAL
- LIVE VERIFY
- DEFERRED

## Documentation updates

Update only affected canonical documents.

## Delivery format

Prefer affected/new files only, preserving project hierarchy. Include an apply/move/delete manifest when necessary.
