# Model and Cost Strategy

## Principle

> Spend expensive reasoning on decisions and hard implementation, not on repetitive ceremony.

AI cost should be proportional to uncertainty, architectural impact, and failure risk.

## Task routing

### Use strongest/high-reasoning capability for

- architecture with large blast radius;
- difficult debugging across many modules;
- security/privacy design;
- migration/data-integrity work;
- complex refactoring;
- ambiguous product/technical tradeoffs;
- final high-value review before a major release.

### Use standard/fast capability for

- bounded implementation after architecture is settled;
- straightforward UI changes;
- documentation updates from known facts;
- repetitive test additions;
- mechanical migration of patterns;
- small bug fixes with clear reproduction.

### Avoid repeated model spending on

- re-reading unchanged plans;
- re-arguing settled decisions;
- verbose status prose;
- asking multiple models for opinions when there is no material disagreement;
- regenerating whole repositories for small changes;
- giant context uploads when a delta/current canonical docs are enough.

## Escalation rule

Start with the least expensive capability that can reliably solve the task.

Escalate when:

- uncertainty is material;
- two attempts fail;
- architecture is unclear;
- security/data integrity is involved;
- regression blast radius is high.

Do not escalate just because a stronger model exists.

## Context efficiency

Prefer:

- canonical project docs over entire historical conversations;
- targeted code areas over the full repository when possible;
- affected-files ZIPs over full-codebase ZIPs for incremental work;
- mission contracts over long conversational restatement;
- durable summaries over repeatedly loading old analysis.

Periodically create a fresh cumulative baseline so delta history does not itself become expensive context.

## Review budget

A good default distribution for substantial AI-assisted engineering effort:

- **60–75%** implementation/debugging/testing
- **10–20%** product/architecture decisions
- **10–15%** validation/review
- **5–10%** documentation/handoff

These are guidelines, not quotas. Security-sensitive work may justify more review.

## Multi-model use

Use a second model/reviewer only when it adds independent value, such as:

- adversarial security review;
- architecture challenge;
- difficult root-cause analysis;
- UX critique;
- release certification.

Do not create an AI committee for ordinary changes.

## Cost is not only tokens

Also optimize:

- human review time;
- failed deployments;
- regressions;
- duplicated code;
- context reconstruction;
- architectural rework.

A slightly more expensive reasoning pass can be cheaper overall if it prevents a major wrong implementation.
