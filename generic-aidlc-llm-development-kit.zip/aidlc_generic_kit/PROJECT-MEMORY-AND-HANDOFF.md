# Project Memory and Handoff

## Problem

Long AI-assisted projects fail when important decisions live only in conversation history.

Conversation is working memory. The repository must become durable memory.

## Minimal canonical memory

Maintain a small set of current files:

### PROJECT-VISION.md
Why the product exists, users, north star, core product principles, strategic boundaries.

### ROADMAP.md
Current priorities plus later/deferred ideas. Never silently delete useful ideas because priority changed.

### MISSION-STATUS.md
What is implemented, partial, live-verify, deferred, and the current active mission.

### CODEBASE.md
High-level architecture, important modules, data flows, migrations, feature registries, commands and known constraints. Keep it current enough that a new agent can orient quickly.

### DEVELOPMENT-RULES.md
Project-specific implementation rules learned over time.

### VALIDATION.md
Current test/gate inventory, latest results, unresolved live verification.

### <ACTIVE-MISSION>.md
The current mission contract.

## Archive rule

Move superseded planning/detail documents under an `archive/` hierarchy instead of deleting them.

The root should answer "what is true now?"
The archive should answer "how did we get here?"

Do not make every new AI session read the archive unless historical comparison is required.

## New-session handoff

A handoff should be short and contain:

1. canonical baseline identity;
2. current product/technical state;
3. active mission;
4. most important constraints;
5. files to read first;
6. validations that must remain green;
7. explicitly deferred work;
8. required delivery format.

Avoid copying the entire project history into every new prompt.

## Cross-model handoff

When moving between Claude/ChatGPT/Codex/another agent:

- do not rely on model-specific memory;
- provide the same canonical files;
- state the baseline explicitly;
- require the new agent to inspect current code before modifying it;
- preserve status semantics and validation rules;
- make model-specific instructions additive, not a replacement for project truth.

## Delta lifecycle

Recommended pattern:

1. Establish cumulative baseline `B0`.
2. Mission produces delta `D1`.
3. Apply and verify.
4. Mission produces delta `D2` against `B0 + D1`.
5. After several deltas, create cumulative baseline `B1`.
6. Archive superseded deltas or retain only for traceability.

Never ask an agent to infer current state from unordered patch archives.

## Decision ledger

For high-impact decisions, record briefly:

- decision;
- reason;
- alternatives rejected;
- revisit trigger.

This prevents future agents from "optimizing away" deliberate constraints.

## Feedback memory

User/customer feedback should not automatically rewrite the roadmap.

Capture:

- source/context;
- frequency;
- severity;
- user segment;
- workaround/blocking status;
- related mission/feature.

Then prioritize based on evidence.

A useful policy:

**blocker > correctness/security/privacy > repeated friction > repeated need > strategic enhancement > one-off preference.**
