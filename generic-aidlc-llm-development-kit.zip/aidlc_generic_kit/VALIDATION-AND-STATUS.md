# Validation and Status Semantics

## Why this matters

AI systems are prone to declaring completion based on source presence, plausible reasoning, or a successful compile. AIDLC requires explicit evidence levels.

## Recommended status vocabulary

### IMPLEMENTED

The feature/code exists and the validation that is possible in the current controlled environment has passed.

This does not automatically imply production verification.

### PARTIAL

A meaningful portion exists, but required behavior/scope is still missing.

State exactly what is missing.

### LIVE VERIFY

Implementation is present, but final truth requires an environment not currently available, such as:

- production/staging database;
- real authorization policies;
- third-party provider;
- production build environment;
- physical/mobile device;
- deployed routing/caching;
- real user behavior.

LIVE VERIFY is not failure. It is epistemic honesty.

### DEFERRED

Intentionally not part of the active mission. Keep it in roadmap/history.

### BLOCKED

Cannot proceed because a concrete dependency is unavailable. Name the dependency and what can still be completed without it.

---

## Validation ladder

Use as many layers as relevant:

1. **Contract/source gate** — expected files, exports, routes, registry entries, migrations.
2. **Static analysis** — typecheck, lint, schema checks.
3. **Build** — production compilation/bundling.
4. **Unit tests** — isolated logic.
5. **Integration tests** — modules collaborating.
6. **Regression gates** — previous missions still work.
7. **E2E/browser** — actual user interaction.
8. **Security matrix** — anonymous/member/admin/etc.
9. **Database/migration** — clean install and upgrade path.
10. **Responsive/accessibility** — representative viewport/device behavior.
11. **Deployment smoke** — staging/production runtime.
12. **User evidence** — comprehension, activation, retention, task completion.

## Gate design lesson

A gate should test behavior/contracts that matter, not merely strings that are easy to assert.

If a bug escapes a gate, strengthen the gate so that class of regression becomes harder to repeat.

Examples:

- broken related-navigation link -> validate all referenced IDs resolve;
- feature added but omitted from rollout control -> validate feature registry vs launch-control registry;
- migration added but docs stale -> validate latest migration/version marker;
- role-specific UI leaks -> role/visibility matrix test.

## Completion report template

At the end of a mission report:

### Implemented
- ...

### Partial
- ...

### Live verify
- ...

### Regression results
- ...

### Remaining risks
- ...

### Next highest-value action
- ...
