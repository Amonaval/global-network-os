# Execution Rules for Claude / AI Coding Agents

These rules can be copied into a project-specific `DEVELOPMENT-RULES.md`.

## Before changing code

1. Identify the canonical baseline.
2. Read current vision, roadmap, mission status, codebase map, validation rules, and the active mission contract.
3. Inspect existing implementation before inventing a new parallel system.
4. Reuse existing abstractions when they are sound.
5. Surface only medium+ disagreements unless a minor issue blocks correctness.

## During planning

- Translate requests into user/business outcomes.
- Keep the active mission bounded.
- Explicitly defer adjacent ideas rather than silently deleting them.
- Prefer the simplest architecture that preserves future extensibility.
- Distinguish product requirement from implementation suggestion.
- Do not repeatedly re-analyze settled architecture once implementation begins unless new evidence invalidates it.

## During implementation

- Preserve existing functionality and deliberate manual fixes.
- Do not remove historical roadmap ideas because priorities change.
- Prefer one source of truth for shared concepts.
- Avoid speculative AI/LLM dependencies when deterministic logic is sufficient.
- Keep destructive data changes governed and migration-safe.
- Add feature/rollout control for functionality that should not immediately reach every user.
- Fix high-value low/medium-effort regressions discovered inside the mission instead of merely documenting them.

## Validation

- Compilation alone is insufficient.
- Run the strongest validation available in the current environment.
- Re-run relevant historical regression gates.
- When a live service/device/environment is unavailable, say exactly what remains LIVE VERIFY.
- Never manufacture a pass for a test that was not actually run.
- Test role, permissions, empty state, failure/recovery, mobile/responsive behavior, and backward compatibility where relevant.

## Documentation

After a meaningful mission, update canonical project memory:

- roadmap;
- mission status;
- codebase map;
- validation record;
- architecture/development rules if a new reusable rule emerged;
- active mission document.

Do not produce documentation churn that merely repeats existing content.

## Delivery

Prefer an affected/new-files delta preserving the original hierarchy.

The final report should separate:

- IMPLEMENTED
- PARTIAL
- LIVE VERIFY
- DEFERRED
- KNOWN RISKS

Include exact remaining actions, not vague "needs more testing" statements.

## Long-running work

If context becomes large:

- summarize durable decisions into canonical files;
- archive superseded planning docs;
- create a concise new-session handoff;
- do not rely on conversational memory as the only project memory.

## Human control

The human remains accountable for:

- product priorities;
- production deployment approval;
- secrets/credentials;
- irreversible migrations;
- legal/compliance decisions;
- accepting security/privacy risk;
- deciding whether measured user evidence justifies a roadmap change.
