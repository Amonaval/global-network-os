# AI-Driven Development Lifecycle (AIDLC) Starter Kit

This folder is a small, generic operating system for building software with LLMs/AI coding agents.

It is intentionally independent of any product, company, stack, or model vendor.

## Why this exists

High-quality AI-assisted engineering is not "one giant prompt -> code". The strongest pattern is a controlled loop:

**Intent -> clarify value -> challenge assumptions -> design a bounded mission -> implement -> validate behavior -> preserve decisions -> ship a small delta -> learn -> repeat.**

The AI may act as product thinker, architect, implementer, reviewer, QA assistant, documentation maintainer, and project-memory aide, but each role has explicit boundaries.

## Read order for a new project

1. `AIDLC-CORE.md` — lifecycle and operating philosophy.
2. `EXECUTION-RULES.md` — rules Claude/another agent should follow while working.
3. `MISSION-TEMPLATE.md` — reusable contract for each major unit of work.
4. `VALIDATION-AND-STATUS.md` — what "done" means and how to avoid false completion.
5. `MODEL-COST-STRATEGY.md` — spend reasoning/tokens where they create value.
6. `PROJECT-MEMORY-AND-HANDOFF.md` — keep long projects coherent across sessions/models.

## Recommended project-local files

For a real project, create these from the templates/principles in this kit:

- `PROJECT-VISION.md`
- `ROADMAP.md`
- `MISSION-STATUS.md`
- `CODEBASE.md`
- `DEVELOPMENT-RULES.md`
- `VALIDATION.md`
- one mission file for the currently active major mission
- `archive/` for superseded historical planning material

## Prime directive

> Use AI to increase product and engineering judgment, not merely code volume.

Prefer a smaller verified implementation over a larger speculative implementation.
