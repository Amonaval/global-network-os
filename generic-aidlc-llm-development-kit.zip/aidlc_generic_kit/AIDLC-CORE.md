# AIDLC Core — AI-Driven Development Lifecycle

## 1. The operating model

AIDLC treats AI as a participant throughout the software lifecycle, not only as a code generator.

A healthy loop is:

1. **Understand the outcome**
2. **Establish the canonical baseline**
3. **Challenge meaningful assumptions**
4. **Define one bounded mission**
5. **Design only enough architecture for that mission**
6. **Implement coherently**
7. **Validate behavior and regressions**
8. **Classify truthfully: implemented / partial / live-verify**
9. **Update project memory and roadmap**
10. **Deliver a minimal delta**
11. **Observe users/runtime evidence**
12. **Prioritize the next mission from evidence**

This is iterative product discovery plus engineering, not prompt chaining for its own sake.

---

## 2. Start with value, not architecture

Before implementation, answer:

- Who is the user?
- What problem becomes easier?
- What behavior should change?
- What is the smallest useful outcome?
- What would make this mission a failure even if the code compiles?

Do not let AI turn an uncertain product idea directly into a large architecture.

---

## 3. Challenge at the correct threshold

AI should not argue about every naming/style preference. It should actively challenge when disagreement is **medium or higher impact**, for example:

- security/privacy risk;
- incorrect data model;
- irreversible architecture;
- serious UX complexity;
- hidden operational cost;
- misleading product assumption;
- unnecessary scope that delays user feedback.

Minor preferences should usually be implemented without debate.

---

## 4. Mission-based development

Never let a long project degrade into an endless stream of unrelated fixes.

Group work into meaningful missions. A mission should have:

- user/business intent;
- included scope;
- excluded/deferred scope;
- architecture constraints;
- acceptance behavior;
- regression requirements;
- documentation updates;
- delivery format.

Prefer coherent batches over micro-missions when the pieces are strongly coupled.

---

## 5. Product discovery is part of implementation

An initial request is not always the best solution.

Use this loop:

**User idea -> infer underlying goal -> brainstorm alternatives -> identify better abstraction -> align -> implement.**

Examples of healthy transformations:

- "add documentation" -> contextual living help + searchable guide + feedback loop;
- "add more features" -> realize activation/retention evidence is now more valuable;
- "build admin controls" -> generalized release/feature rollout control;
- "show relationship graph" -> explainable paths + impact reasoning.

The AI should preserve the original intent while improving the solution.

---

## 6. Canonical baseline discipline

At any moment there should be exactly one canonical code baseline.

Rules:

- Never silently restart from an older ZIP/branch/snapshot.
- Patches are deltas, not new sources of truth.
- After enough patches accumulate, produce/establish a fresh cumulative baseline.
- Record the baseline identity/version in project docs.
- Never reconstruct current state by guessing which old patches were applied.

This prevents one of the most expensive long-running-agent failures: regression from stale context.

---

## 7. Delta-first delivery

When practical, deliver only affected/new files with original folder hierarchy.

Benefits:

- less token/context use;
- easier human review;
- smaller artifact transfer;
- clearer blast radius;
- reduced chance of overwriting manual fixes;
- easier comparison and rollback.

For destructive/move operations, include an explicit apply script or manifest if a delta ZIP alone cannot express deletion/moves.

---

## 8. One source of truth for repeated concepts

Avoid duplicating long definitions/configuration/help text across many components.

Prefer structured registries/configuration that can power multiple surfaces:

- UI;
- validation;
- search/help;
- feature visibility;
- documentation generation;
- future AI assistance.

This makes later AI work safer because there are fewer conflicting truths.

---

## 9. Behavior over source assertions

"The component exists" is not the same as "the feature works".

Validation layers should progress through:

1. source/static assertions;
2. typecheck/lint;
3. build;
4. unit/integration tests;
5. deterministic behavior gates;
6. browser/E2E flows;
7. real database/security policies;
8. deployed/runtime/device verification;
9. actual user evidence.

Do not collapse these into a single `DONE` label.

---

## 10. Progressive product exposure

A feature can be technically implemented without being appropriate for every user.

Use rollout states such as:

- Hidden
- Test
- Pilot
- Released

Optionally vary by:

- tenant/customer;
- role;
- experience level;
- environment;
- geography;
- demo/playground vs real data.

This lets teams build ahead without overwhelming users or prematurely promising behavior.

---

## 11. Evidence-driven freeze

There is a point where adding features reduces learning.

When the product is sufficiently capable:

1. freeze broad feature development;
2. expose a deliberate subset;
3. let real users work;
4. classify feedback;
5. fix blockers first;
6. prioritize repeated friction/needs;
7. keep lower-confidence ideas in roadmap rather than immediately implementing them.

A useful priority order:

**Blocking -> correctness/security/privacy -> repeated friction -> repeated user need -> activation/retention improvement -> planned roadmap -> speculative ideas.**

---

## 12. What AI should optimize

Optimize for:

- decision quality;
- implementation correctness;
- user value;
- maintainability;
- verifiability;
- low regression risk;
- preserved project knowledge;
- cost-efficient iteration.

Do not optimize for:

- number of generated files;
- amount of prose;
- maximum feature count;
- maximum autonomous activity;
- falsely clean status reports.
