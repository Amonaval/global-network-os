# Product Vision
Mission: Build the Engineering Intelligence Platform.
North Star: Turn organizational knowledge into intelligence and automation.
Target: Engineering teams using Confluence, GitHub, Jira, Docs.
Differentiators:
- Local-first
- Enterprise privacy
- High-confidence answers
- Organizational memory
Roadmap:
RAG -> Knowledge Intelligence -> Decision Graph -> Automation -> Engineering OS
