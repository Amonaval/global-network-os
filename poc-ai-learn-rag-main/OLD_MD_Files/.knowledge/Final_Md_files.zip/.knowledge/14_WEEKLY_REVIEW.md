# Weekly Review

## Biggest Win

...

## Biggest Mistake

...

## Biggest Risk

...

## Biggest Opportunity

...

## Technical Debt

...

## Documentation Debt

...

## Product Debt

...

## Top 5 Priorities

...

## Features to Remove

...

## Architecture Concerns

...

## Should Roadmap Change?

...