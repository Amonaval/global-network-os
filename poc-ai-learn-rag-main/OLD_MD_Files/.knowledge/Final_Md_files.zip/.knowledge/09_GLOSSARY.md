# Glossary
Knowledge Graph
Decision Graph
Confidence Gate
Hybrid Retrieval
Documentation Intelligence
Organizational Memory
