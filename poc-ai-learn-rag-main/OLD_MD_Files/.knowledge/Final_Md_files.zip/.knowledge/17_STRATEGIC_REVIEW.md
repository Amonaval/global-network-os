Am I solving

the current problem

or

the most important problem?