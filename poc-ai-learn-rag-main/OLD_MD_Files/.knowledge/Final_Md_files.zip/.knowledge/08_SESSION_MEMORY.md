# Session Memory
Store only:
- Decisions
- Lessons
- Discoveries
- Rejected ideas
Never store chronological logs.
