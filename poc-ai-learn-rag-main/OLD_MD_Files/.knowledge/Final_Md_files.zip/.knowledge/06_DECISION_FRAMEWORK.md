# Decision Framework
Priority:
1 Customer Value
2 Competitive Moat
3 Simplicity
4 Maintainability
5 Performance
Reject: rewrites, hype frameworks, feature bloat.
