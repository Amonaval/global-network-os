# Work Queue

## NOW

Highest priority.

Exactly one active mission.

---

## NEXT

Next three features.

---

## LATER

Important but not urgent.

---

## ICEBOX

Interesting ideas.

---

## COMPLETED

Move completed work here.

Keep only last 20 items.

Everything older belongs in Session Memory.