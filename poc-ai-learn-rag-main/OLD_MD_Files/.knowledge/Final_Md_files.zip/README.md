# Knowledge Hub AI Company Operating System
Purpose: High-value, low-token AI collaboration.
Folder roles:
.knowledge = compressed intelligence
prompts = reusable prompts
templates = reusable docs
