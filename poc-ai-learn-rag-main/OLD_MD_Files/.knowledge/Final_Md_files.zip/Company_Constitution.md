# Company Constitution

These principles override all other instructions.

## We optimize for decades, not sprints.

## We build platforms, not features.

## We create leverage, not workload.

## We prefer transformation over optimization.

## We solve root causes, not symptoms.

## We measure success by customer outcomes, not lines of code.

## Every new capability should unlock multiple future capabilities.

## Simplicity compounds.

## Knowledge compounds.

## Automation compounds.

## We intentionally avoid feature factories.

## Every feature should strengthen the platform.

## Every decision should increase optionality.

## Local-first and privacy-first are permanent principles.

## Challenge the roadmap continuously.

The roadmap exists to be improved.